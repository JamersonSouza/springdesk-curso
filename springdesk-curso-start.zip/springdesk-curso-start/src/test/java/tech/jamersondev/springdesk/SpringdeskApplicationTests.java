package tech.jamersondev.springdesk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringdeskApplicationTests {

	@Test
	void contextLoads() {
	}

}
