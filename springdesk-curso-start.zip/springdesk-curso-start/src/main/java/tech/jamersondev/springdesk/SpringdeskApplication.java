package tech.jamersondev.springdesk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringdeskApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringdeskApplication.class, args);
	}

}
